<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        // $schedule->command('inspire')->hourly();
        $schedule->command('attendance:send-daily-report')
             ->dailyAt('09:30')           // Every day at 9:30 AM
             ->timezone('Asia/Dhaka')
             ->days([1,2,3,4,5,6])        // Mon–Sat (remove if Sunday also working)
             ->onSuccess(function () {
                 \Log::info('Daily attendance email sent successfully.');
             })
             ->onFailure(function () {
                 \Log::error('Failed to send daily attendance email.');
             });
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
