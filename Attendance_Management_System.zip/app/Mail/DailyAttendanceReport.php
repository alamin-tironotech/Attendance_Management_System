<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class DailyAttendanceReport extends Mailable
{
    use Queueable, SerializesModels;

    public $attendance;
    public $date;
    public $summary;


    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($attendance, $date, $summary)
    {
        $this->attendance = $attendance;
        $this->date = $date;
        $this->summary = $summary;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject('Daily Attendance Report-'.$this->date)->markdown('emails.attendance.daily');
    }
}
